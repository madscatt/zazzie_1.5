The following files show which papers are the source for various
measured neutron scattering cross section data:
   nsf.pdf             the real-valued cross sections
   nsfimaginary.pdf    the imaginary part of the cross sections
   nsfreferences.html  the source papers for the measurements
They were retrieved from http://www.ati.ac.at/~neutropt/scattering
in March 2008.
